<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <header>
        <div class="page_menu">
            <ul class="page_menu-ul">
                <li class="page_menu-li"><a href="index.php" class="page_menu-link">Главная страница</a></li>
                <li class="page_menu-li"><a href="output.php" class="page_menu-link">Вывод данных</a></li>
            </ul>
        </div>
    </header>