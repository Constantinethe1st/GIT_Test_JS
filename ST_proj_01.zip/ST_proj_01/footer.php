<footer>
        <div class="footer_menu">
            <ul class="footer_menu-ul">
                <li class="footer_menu-li"><a href="index.php" class="footer_menu-link">Главная страница</a></li>
                <li class="footer_menu-li"><a href="output.php" class="footer_menu-link">Вывод данных</a></li>
            </ul>
        </div>
        <div class="copyrightAndContacts">
            <h6 class="copyrightAndContacts_copy">Все права защищены &copy; 2007 год.</h6>
        </div>
    </footer>
    </div>
</body>
</html>