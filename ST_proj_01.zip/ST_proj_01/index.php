    <?php
        $title = 'Главная страница';
        require_once "header.php";
    ?>
    <h1 class="formTitle">Форма обратной связи</h1>
    <form action="output.php" method="post" class="formIndex"><br>
        <input type="text" name="userName" placeholder="Введите имя" class="form-control"><br>
        <input type="text" name="userLastName" placeholder="Введите фамилию" class="form-control"><br>
        <input type="tel" name="userTel" placeholder="Введите телефонный номер" class="form-control"><br>
        <input type="text" name="userCity" placeholder="Введите название города" class="form-control"><br>
        <textarea rows="5" cols="100" name="userMassage" placeholder="Введите текст сообщения" class="form-control"></textarea>
        <p>
            <h5 class="input_h5">Пользователь дает свое согласие на обработку его персональных данных, а именно совершение действий, 
                предусмотренных п. 3 ч. 1 ст. 3 Федерального закона от 27.07.2006 N 152-ФЗ "О персональных данных", и подтверждает, что, 
                давая такое согласие, он действует свободно, своей волей и в своем интересе.</h5>
            <input type="radio" name="agreement" value="radio_1" checked> Согласен!<br>
            <input type="radio" name="agreement" value="radio_2"> Не-а!
        </p>
        <input type="submit" name="submitForm" value="Отправить" class="btn btn-success">
    </form>
    <?php
        require "footer.php";
    ?>