    <?php
        $title = 'Вывод данных';
        require_once "header.php";
    ?>
    <h1>Вывод данных</h1>
    <?php
        // print_r($_POST); - выводит данные массива строкой 
            $userName = $_POST['userName'];
            $userLastName = $_POST['userLastName'];
            $userTel = $_POST['userTel'];
            $userCity = $_POST['userCity'];
            $userMassage = $_POST['userMassage'];
            $agreement = $_POST['agreement'];

        if ($agreement == 'radio_1'){
                if (trim($userName) == "" || 
                    trim($userLastName) == "" || 
                    trim($userTel) == "" || 
                    trim($userCity) == "" || 
                    trim($_POST['userMassage']) == "" || 
                    trim($agreement) == ""){
                        echo "Заполните каждое поле формы!";
                } else if (strlen(trim($userName)) <= 1 || 
                    strlen(trim($userLastName)) <= 1 || 
                    strlen(trim($userTel)) <= 1 || 
                    strlen(trim($userCity)) <= 1 || 
                    strlen(trim($_POST['userMassage'])) <= 1){
                        echo "Укажите данные полностью!";
                } else if (strlen(trim($userName)) > 30 || 
                strlen(trim($userLastName)) > 30 || 
                strlen(trim($userTel)) > 30 || 
                strlen(trim($userCity)) > 30 || 
                strlen(trim($_POST['userMassage'])) > 2000){
                    echo "Слишком много букв!";
                } else {
                    echo '<h5>Получены данные:<h5>'.'<br>';
                    echo $userName.'<br>';
                    echo $userLastName.'<br>';
                    echo $userTel.'<br>';
                    echo $userCity.'<br>';
                    echo $userMassage.'<br>';
                }
            } else {
                echo "Для отправки сообщения необходимо дать согласие на обработку данных!";
            }              
    ?>
    <?php
        require "footer.php";
    ?>