<?php
        $title = 'Главная страница';
        require_once "header.php";
    ?>
<?php
    

$userName = $userLastName = $userEmail = $userTel = $userCity = $userMassage = $agreement = '';
$nameErr = $lastNameErr = $emailErr = $telErr = $cityErr = $massageErr = $agreementErr = '';

//         $_SERVER ["PHP_SELF"] — это суперглобальная переменная, которая возвращает имя файла текущего выполняемого скрипта-обработчика.
// Переменная $_SERVER ["PHP_SELF"] отправляет данные из формы на саму же страницу с формой, вместо перехода на другую страницу. 
// Таким образом, пользователь будет получать сообщения об ошибках на той же странице, где заполняется форма.
// Функция htmlspecialchars() преобразует данные, введенные пользователем, которые могут содержать нежелательные HTML-тэги.
// stripslashes() — удаляет экранирование символов.
// empty — Проверяет, пуста ли переменная/
// Функция preg_match() ищет в строке $name шаблон, возвращая true, если шаблон существует, и false, если данные в строке не соответсвуют шаблону.

// print_r($_POST); - выводит данные массива строкой 

if ($_SERVER["REQUEST_METHOD"] == "POST"){
    if ($_POST['agreement'] === "Анонимус."){
        $agreementErr = "Для отправки обращения необходимо дать согласие на обработку данных!";
    } else {
            if (empty($_POST['userName'])){
                $nameErr = "Введите имя!";
                } else if (!preg_match("/^(([a-zA-Z' -]{1,30})|([а-яА-ЯЁёІіЇїҐґЄє' -]{1,30}))$/u",$_POST['userName'])){
                    $nameErr = "Введите корректное имя!";
                    } else {$userName = test_input($_POST['userName']);
                            $_SESSION['userName'] = $userName;
                        }

            if (empty($_POST['userLastName'])){
                $lastNameErr = "";
                } else if (!preg_match("/^(([a-zA-Z' -]{1,30})|([а-яА-ЯЁёІіЇїҐґЄє' -]{1,30}))$/u",$_POST['userLastName'])) {
                    $lastNameErr = "Введите корректно фамилию!";
                    } else {$userLastName = test_input($_POST['userLastName']);
                        $_SESSION['userLastName'] = $userLastName;
                        }

            if (empty($_POST['userEmail'])){
                $emailErr = "Введите электронную почту!";
                } else if (!filter_var($_POST['userEmail'], FILTER_VALIDATE_EMAIL)){
                    $emailErr = "Некорректно введён адрес email!";
                    } else {$userEmail = test_input($_POST['userEmail']);
                        $_SESSION['userEmail'] = $userEmail;
                        }
                
            if (empty($_POST['userTel'])){
                $telErr = "";
                } else if (!preg_match("/^((8|\+7)[\- ]?)?(\(?\d{3}\)?[\- ]?)?[\d\- ]{7,10}$/", $_POST['userTel'])){
                    $telErr = "Введите корректный номер!";
                    } else {$userTel = test_input($_POST['userTel']);
                        $_SESSION['userTel'] = $userTel;
                        }

            if (empty($_POST['userCity'])){
                $cityErr = "";
                } else if (!preg_match("/^(([a-zA-Z' -]{1,40})|([а-яА-ЯЁёІіЇїҐґЄє' -]{1,40}))$/u",$_POST['userCity'])){
                    $cityErr = "Введите корректно название города!";
                    } else {$userCity = test_input($_POST['userCity']);
                        $_SESSION['userCity'] = $userCity;
                        }
                    
            if (empty($_POST['userMassage'])){
                $massageErr = "Введите текст сообщения!";
                } else if (strlen(trim($_POST['userMassage'])) > 300){
                    $massageErr = "Слишком много букв!";
                    } else {$userMassage = test_input($_POST['userMassage']);
                        $_SESSION['userMassage'] = $userMassage;
                        }
    }
}

function test_input($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


?>
    <h1 class="formTitle">Форма обратной связи</h1><br>
    <span class="text-danger"><?php echo $agreementErr;?></span><br>
    <!-- output.php -->
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" class="formIndex"><br>
            <span class="text-danger"><?php echo $nameErr;?></span>
        <input type="text" name="userName" placeholder="Введите имя *" class="form-control"><br>
            <span class="text-danger"><?php echo $lastNameErr;?></span>
        <input type="text" name="userLastName" placeholder="Введите фамилию" class="form-control"><br>
            <span class="text-danger"><?php echo $emailErr;?></span>
        <input type="text" name="userEmail" placeholder="Введите электронную почту *" class="form-control"><br>
            <span class="text-danger"><?php echo $telErr;?></span>
        <input type="tel" name="userTel" placeholder="Введите телефонный номер" class="form-control"><br>
            <span class="text-danger"><?php echo $cityErr;?></span>
        <input type="text" name="userCity" placeholder="Введите название города" class="form-control"><br>
            <span class="text-danger"><?php echo $massageErr;?></span>
        <textarea rows="5" cols="100" name="userMassage" placeholder="Введите текст сообщения *" class="form-control"></textarea>
        <p>
            <h5 class="input_h5">Пользователь дает свое согласие на обработку его персональных данных, а именно совершение действий, 
                предусмотренных п. 3 ч. 1 ст. 3 Федерального закона от 27.07.2006 N 152-ФЗ "О персональных данных", и подтверждает, что, 
                давая такое согласие, он действует свободно, своей волей и в своем интересе.</h5>
            <input type="radio" name="agreement" value="Согласен на обработку данных!" checked> Согласен!<br>
            <input type="radio" name="agreement" value="Анонимус."> Не-а!
        </p>
        <input type="submit" name="submitForm" value="Отправить" class="btn btn-success">
    </form>

    
<?php
        require "footer.php";
    ?>   