<?php
        $title = 'Вывод данных';
        require_once "header.php";
    ?>
    <h1>Вывод данных</h1>
<?php
        
            // $userName = $_POST['userName'];
            // $userLastName = $_POST['userLastName'];
            // $userEmail = $_POST['userEmail'];
            // $userTel = $_POST['userTel'];
            // $userCity = $_POST['userCity'];
            // $userMassage = $_POST['userMassage'];
            // $agreement = $_POST['agreement'];
    
echo $_SESSION['userName'];
echo "<br>";
echo $_SESSION['userLastName'];
echo "<br>";
echo $_SESSION['userEmail'];
echo "<br>";
echo $_SESSION['userTel'];
echo "<br>";
echo $_SESSION['userCity'];
echo "<br>";
echo $_SESSION['userMassage'];
?>
<?php
        require "footer.php";
    ?>